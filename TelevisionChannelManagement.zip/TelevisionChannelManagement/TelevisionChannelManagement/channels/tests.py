from django.test import TestCase
from django.contrib.auth.models import User
from .models import Channel

class ChannelModelTest(TestCase):
    def setUp(self):
        # Create a user for testing
        self.user = User.objects.create_user(username='testuser', password='password123')

    def test_channel_creation(self):
        # Test that a Channel can be created
        channel = Channel.objects.create(
            name='Test Channel',
            description='This is a test channel.',
            created_by=self.user
        )
        self.assertEqual(channel.name, 'Test Channel')
        self.assertEqual(channel.description, 'This is a test channel.')
        self.assertEqual(channel.created_by, self.user)

    def test_channel_string_representation(self):
        # Test the string representation of the Channel
        channel = Channel.objects.create(
            name='Test Channel',
            description='This is a test channel.',
            created_by=self.user
        )
        self.assertEqual(str(channel), 'Test Channel')

    def test_channel_count(self):
        # Test the count of channels
        Channel.objects.create(
            name='Test Channel 1',
            description='Description 1',
            created_by=self.user
        )
        Channel.objects.create(
            name='Test Channel 2',
            description='Description 2',
            created_by=self.user
        )
        self.assertEqual(Channel.objects.count(), 2)


class ChannelViewTest(TestCase):
    def setUp(self):
        # Create a user for testing
        self.user = User.objects.create_user(username='testuser', password='password123')
        self.client.login(username='testuser', password='password123')

    def test_channel_list_view(self):
        # Test the channel list view
        response = self.client.get('/channels/')
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'channels/channel_list.html')

    def test_add_channel_view(self):
        # Test adding a channel
        response = self.client.post('/channels/add_channel/', {
            'name': 'New Test Channel',
            'description': 'This is a new test channel.'
        })
        self.assertEqual(response.status_code, 302)  # Check for redirect after successful post
        self.assertEqual(Channel.objects.count(), 1)
        self.assertEqual(Channel.objects.first().name, 'New Test Channel')

    def test_edit_channel_view(self):
        # Test editing a channel
        channel = Channel.objects.create(
            name='Editable Channel',
            description='Editable description',
            created_by=self.user
        )
        response = self.client.post(f'/channels/edit_channel/{channel.id}/', {
            'name': 'Updated Channel',
            'description': 'Updated description'
        })
        self.assertEqual(response.status_code, 302)  # Check for redirect after successful edit
        channel.refresh_from_db()
        self.assertEqual(channel.name, 'Updated Channel')

    def test_delete_channel_view(self):
        # Test deleting a channel
        channel = Channel.objects.create(
            name='Deletable Channel',
            description='Deletable description',
            created_by=self.user
        )
        response = self.client.post(f'/channels/delete_channel/{channel.id}/')
        self.assertEqual(response.status_code, 302)  # Check for redirect after deletion
        self.assertEqual(Channel.objects.count(), 0)

