from django.views import View
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from .models import Channel

class RegisterView(View):
    def get(self, request):
        form = UserCreationForm()
        return render(request, 'channels/register.html', {'form': form})

    def post(self, request):
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=password)
            login(request, user)
            messages.success(request, 'Registration successful!')  # Success message
            return redirect('channel_list')
        messages.error(request, 'Error registering. Please check the form.')
        return render(request, 'channels/register.html', {'form': form})

class LoginView(View):
    def get(self, request):
        return render(request, 'channels/login.html')

    def post(self, request):
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, 'Login successful!')  # Success message
            return redirect('channel_list')
        messages.error(request, 'Invalid credentials')
        return render(request, 'channels/login.html')

class LogoutView(View):
    def get(self, request):
        logout(request)
        messages.success(request, 'You have been logged out.')  # Success message
        return redirect('login')

class AddChannelView(View):
    def get(self, request):
        return render(request, 'channels/add_channel.html')

    def post(self, request):
        name = request.POST['name']
        description = request.POST['description']
        Channel.objects.create(name=name, description=description, created_by=request.user)
        messages.success(request, f'Channel "{name}" added successfully!')  # Success message
        return redirect('channel_list')

class ChannelListView(View):
    def get(self, request):
        channels = Channel.objects.all()
        return render(request, 'channels/channel_list.html', {'channels': channels})

class EditChannelView(View):
    def get(self, request, channel_id):
        channel = get_object_or_404(Channel, id=channel_id)
        return render(request, 'channels/edit_channel.html', {'channel': channel})

    def post(self, request, channel_id):
        channel = get_object_or_404(Channel, id=channel_id)
        channel.name = request.POST['name']
        channel.description = request.POST['description']
        channel.save()
        messages.success(request, f'Channel "{channel.name}" updated successfully!')  # Success message
        return redirect('channel_list')

class DeleteChannelView(View):
    def get(self, request, channel_id):
        channel = get_object_or_404(Channel, id=channel_id)
        channel.delete()
        messages.success(request, f'Channel "{channel.name}" deleted successfully!')  # Success message
        return redirect('channel_list')

class ChannelOperationsView(View):
    def get(self, request, channel_type):
        channels = Channel.objects.filter(name__icontains=channel_type)
        return render(request, 'channels/channel_operations.html', {'channels': channels, 'channel_type': channel_type})

    def post(self, request, channel_type):
        if 'add' in request.POST:
            name = request.POST['name']
            description = request.POST['description']
            Channel.objects.create(name=name, description=description, created_by=request.user)
            messages.success(request, f'Channel "{name}" added successfully!')  # Success message
        elif 'edit' in request.POST:
            channel_id = request.POST['channel_id']
            channel = get_object_or_404(Channel, id=channel_id)
            channel.name = request.POST['name']
            channel.description = request.POST['description']
            channel.save()
            messages.success(request, f'Channel "{channel.name}" updated successfully!')  # Success message
        elif 'delete' in request.POST:
            channel_id = request.POST['channel_id']
            channel = get_object_or_404(Channel, id=channel_id)
            channel.delete()
            messages.success(request, f'Channel "{channel.name}" deleted successfully!')  # Success message

        channels = Channel.objects.filter(name__icontains=channel_type)
        return render(request, 'channels/channel_operations.html', {'channels': channels, 'channel_type': channel_type})

# Specific channel views extending ChannelOperationsView
class SportsChannelView(ChannelOperationsView):
    def get(self, request):
        return super().get(request, 'Sports Channel')

class NewsChannelView(ChannelOperationsView):
    def get(self, request):
        return super().get(request, 'News Channel')

class KidsChannelView(ChannelOperationsView):
    def get(self, request):
        return super().get(request, 'Kids Channel')

class MovieChannelView(ChannelOperationsView):
    def get(self, request):
        return super().get(request, 'Movie Channel')

class MusicChannelView(ChannelOperationsView):
    def get(self, request):
        return super().get(request, 'Music Channel')
