from django.urls import path
from .views import (
    RegisterView,
    LoginView,
    LogoutView,
    AddChannelView,
    ChannelListView,
    EditChannelView,
    DeleteChannelView,
    SportsChannelView,
    NewsChannelView,
    KidsChannelView,
    MovieChannelView,
    MusicChannelView,
)

urlpatterns = [
    path('register/', RegisterView.as_view(), name='register'),
    path('login/', LoginView.as_view(), name='login'),
    path('logout/', LogoutView.as_view(), name='logout'),
    path('add_channel/', AddChannelView.as_view(), name='add_channel'),
    path('channels/', ChannelListView.as_view(), name='channel_list'),  # Make sure this line exists
    path('edit_channel/<int:channel_id>/', EditChannelView.as_view(), name='edit_channel'),
    path('delete_channel/<int:channel_id>/', DeleteChannelView.as_view(), name='delete_channel'),
    path('sports_channel/', SportsChannelView.as_view(), name='sports_channel'),
    path('news_channel/', NewsChannelView.as_view(), name='news_channel'),
    path('kids_channel/', KidsChannelView.as_view(), name='kids_channel'),
    path('movie_channel/', MovieChannelView.as_view(), name='movie_channel'),
    path('music_channel/', MusicChannelView.as_view(), name='music_channel'),
]
